import psutil

print(f"{'PID':>8} {'NAME':<25} {'MEMORY%':>10} {'CPU%':>8}")
print("-"*55)

for proc in psutil.process_iter():
    try:
        pid = proc.pid
        name = proc.name()
        mem = proc.memory_percent()
        cpu = proc.cpu_percent(interval=0.1)

        print(f"{pid:>8} {name:<25} {mem:>10.2f} {cpu:>8.2f}")

    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
        pass
