
# Import the threading module
import threading


# Function one: prints a message
def task_one():
    """Function executed by thread one."""
    print("Thread 1 is running task_one")


# Function two: prints a message
def task_two():
    """Function executed by thread two."""
    print("Thread 2 is running task_two")


# Main program execution
def main():
    """Creates and manages threads."""

    # Create threads and assign functions
    thread1 = threading.Thread(target=task_one)
    thread2 = threading.Thread(target=task_two)

    # Start threads
    thread1.start()
    thread2.start()

    # Wait for both threads to finish
    thread1.join()
    thread2.join()

    print("Both threads have completed execution.")


# Run the main function
if __name__ == "__main__":
    main()