"""
processes.py
Displays CPU and memory information using psutil.
"""

import psutil


def bytes_to_gb(bytes_value):
    """Convert bytes to gigabytes."""
    return bytes_value / (1024 ** 3)


def main():
    # CPU Information
    cpu_usage = psutil.cpu_percent(interval=1)
    cpu_logical = psutil.cpu_count(logical=True)
    cpu_physical = psutil.cpu_count(logical=False)

    # Memory Information
    memory = psutil.virtual_memory()

    total_memory = bytes_to_gb(memory.total)
    available_memory = bytes_to_gb(memory.available)
    used_memory = bytes_to_gb(memory.used)
    memory_percent = memory.percent

    # Display Results
    print("===== CPU Information =====")
    print(f"CPU Usage: {cpu_usage}%")
    print(f"Logical CPU Count: {cpu_logical}")
    print(f"Physical CPU Count: {cpu_physical}")

    print("\n===== Memory Information =====")
    print(f"Total Memory: {total_memory:.2f} GB")
    print(f"Available Memory: {available_memory:.2f} GB")
    print(f"Used Memory: {used_memory:.2f} GB")
    print(f"Memory Usage Percentage: {memory_percent}%")


if __name__ == "__main__":
    main()