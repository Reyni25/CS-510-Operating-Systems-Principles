import threading
import time
import random

# Semaphore initialization value
SEMAPHORE_LIMIT = 1

# Total number of threads
TOTAL_THREADS = 6

# Create semaphore
resource_semaphore = threading.Semaphore(SEMAPHORE_LIMIT)

# Lock for clean output
print_lock = threading.Lock()

def worker(thread_id):

    with print_lock:
        print(f"Thread-{thread_id} waiting for resource")

    resource_semaphore.acquire()

    try:
        with print_lock:
            print(f"Thread-{thread_id} entered critical section")

        work_time = random.uniform(1, 3)
        time.sleep(work_time)

        with print_lock:
            print(f"Thread-{thread_id} leaving critical section")

    finally:
        resource_semaphore.release()

        with print_lock:
            print(f"Thread-{thread_id} released semaphore")


def main():

    threads = []

    print("Semaphore Synchronization Demo")
    print("Max concurrent threads:", SEMAPHORE_LIMIT)

    for i in range(1, TOTAL_THREADS + 1):
        thread = threading.Thread(target=worker, args=(i,))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    print("All threads finished.")


if __name__ == "__main__":
    main()