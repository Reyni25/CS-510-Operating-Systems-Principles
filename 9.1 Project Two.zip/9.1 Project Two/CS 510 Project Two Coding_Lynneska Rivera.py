"""
    Class:   CS-510
    Author:  Lynneska Rivera Perez
    Date:    April 3, 2026

    Description:  Each function that needs to be completed has a comment at the top with
                  TODO written in it with instructions.

                  Within the function is a section with the comment #TODO where you will
                  insert your code as per the instructions.
"""  
import os
import psutil  # requires pip install
import sys
import threading

"""
  Three provided Utility functions to use
"""
def printBlankLines(lines: int):
    for i in range(lines):
        print("")

def printMsg1(num):
    print("Thread 1 cubed: {}" .format(num * num * num))


def printMsg2(num):
    print("Thread 2 squared: {}" .format(num * num))


"""
   TODO This function will display information about a file, size and file information.
   You can provide your own or use the projecttwo.txt file.

   Use psutil to get initial file information.
"""

import time


def getFileDiskUsageStatistics() -> None:
    print("Getting Disk Statistics")
    file_name = "projecttwo.txt"
    # prefer __file__ when available, otherwise fall back to cwd
    script_dir = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
    

    # Disk Usage
    disk = psutil.disk_usage('/')
    print(f"Total Disk Space: {disk.total / (1024**3):.2f} GB")
    print(f"Free Disk Space: {disk.free / (1024**3):.2f} GB")

    # Build candidate locations to search for the file
    candidates = [
        os.path.join(script_dir, file_name),
        os.path.join(os.getcwd(), file_name),
        os.path.join(os.path.expanduser('~'), file_name),
    ]

    # also check up to 3 parent directories of the script directory
    parent = script_dir
    for _ in range(3):
        parent = os.path.dirname(parent)
        if parent:
            candidates.append(os.path.join(parent, file_name))

    file_path = None
    for candidate in candidates:
        if os.path.exists(candidate):
            file_path = candidate
            break

    if not file_path:
        print(f"\nFile '{file_name}' not found in searched locations:")
        for c in candidates:
            print("  " + c)
        # try to create a sample file next to the script so subsequent runs find it
        try:
            file_path = os.path.join(script_dir, file_name)
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write("Sample projecttwo.txt created by script.\n")
            print(f"Created sample file at {file_path}")
        except Exception as e:
            print(f"Could not create sample file at {script_dir}: {e}")
            printBlankLines(2)
            return        

    # File info
    

    try:
        stats = os.stat(file_path)
        print(f"\nFile: {os.path.basename(file_path)}")
        print(f"Path: {file_path}")
        print(f"Size: {stats.st_size} bytes")
        # Convert timestamp to readable format
        readable_time = time.ctime(stats.st_mtime)
        print(f"Last Modified: {readable_time}")
    except Exception as e:
        print(f"Error accessing file: {e}")


    printBlankLines(2)

"""
   TODO This should use psutil to retrieve standard and 
   virtual memory statistics
"""
def getMemoryStatistics() -> None:
    print("Getting Memory Statistics")

    mem = psutil.virtual_memory()
    swap = psutil.swap_memory()

    print(f"Total Memory: {mem.total / (1024**3):.2f} GB")
    print(f"Used Memory: {mem.used / (1024**3):.2f} GB")
    print(f"Memory Usage: {mem.percent}%")

    print(f"Virtual Memory (Swap) Used: {swap.used / (1024**3):.2f} GB")

    printBlankLines(2)

"""
   TODO This should use psutil to retrieve CPU statistics, including
   information on processes.
"""
def getCpuStatistics() -> None:
    print("Getting CPU Statistics")
    
    print(f"CPU Cores: {psutil.cpu_count(logical=True)}")
    print(f"CPU Usage: {psutil.cpu_percent(interval=1)}%")

    print("\nTop 3 Processes by CPU Usage:")
    processes = sorted(psutil.process_iter(['pid','name','cpu_percent']),
                       key=lambda p: p.info['cpu_percent'],
                       reverse=True)
    
    for proc in processes[:3]:
        print(f"PID: {proc.info['pid']}, Name: {proc.info['name']}, CPU: {proc.info['cpu_percent']}%")
    printBlankLines(2)


"""
   TODO This function will show multi threading capabilities.

   Two threads should be created.
    
   One used to call the function "printMsg1" provided above.

   A second thread should call the function "printMsg2" provided above.
"""
def showThreadingExample() -> None:
    print("Demonstrating Threading")
   
    thread1 = threading.Thread(target=printMsg1, args=(3,))
    thread2 = threading.Thread(target=printMsg2,args=(3,))

    print("Starting Threads...")
    thread1.start()
    thread2.start()

    thread1.join()
    thread2.join()

    print("Threads Completed")
    print("Done With Threading!")

    printBlankLines(2)

"""
   TODO This function shows system error handling.

   Since out of memory, or out of disk space errors are difficult to create,
   we will use a divide by zero error and show the error handling being executed.
"""
def showErrorHandling() -> None:
    print("Demonstrating Error Handling")
    try:
        res = 10 / 0 # intentional error

       
    except ZeroDivisionError:
        print("You can't divide by zero!")
        
    except MemoryError:
        print("Memory Error!")
        
    else:
        print("Result is", res)
        
    finally:
        print("Execution complete.")

    printBlankLines(2)

"""
   Main function, does not require modification.

   This calls the specific functions.
"""
def main() -> int:
    print("Starting Program")
    print("=============================")
   
    getFileDiskUsageStatistics()   
    
    getCpuStatistics()
    
    getMemoryStatistics()

    showThreadingExample()

    showErrorHandling()


if __name__ == '__main__':
    sys.exit(main()) 